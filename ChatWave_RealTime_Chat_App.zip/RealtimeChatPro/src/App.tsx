import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import {
  ArrowDownLeft, ArrowUpRight, Bell, Check, CheckCheck, ChevronDown, CircleHelp,
  FilePlus2, Image as ImageIcon, LogOut, Menu, MessageCircle, Moon, MoreHorizontal,
  Paperclip, Phone, Plus, Search, Send, Settings, ShieldCheck, Smile, Sun, Users,
  Video, X, UserPlus, Languages, LockKeyhole, Sparkles
} from 'lucide-react';
import { isConfigured, supabase } from './lib/supabase';

type Profile = { id: string; username: string; display_name: string; avatar_url?: string | null; bio?: string | null; };
type Conversation = { id: string; title: string | null; is_group: boolean; updated_at: string; };
type Message = { id: string; conversation_id: string; sender_id: string; content: string; created_at: string; edited_at?: string | null; };
type Friend = { id: string; requester_id: string; addressee_id: string; status: string; };

const colors = ['#8b7cff', '#22c7a9', '#ff9d66', '#e66cae', '#5ca9ff'];
const initials = (s = 'U') => s.trim().split(/\\s+/).slice(0, 2).map(p => p[0]?.toUpperCase()).join('');
const timeLabel = (s: string) => new Date(s).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [active, setActive] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [friends, setFriends] = useState<Profile[]>([]);
  const [query, setQuery] = useState('');
  const [people, setPeople] = useState<Profile[]>([]);
  const [draft, setDraft] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [dark, setDark] = useState(true);
  const [rtl, setRtl] = useState(false);
  const [mobilePanel, setMobilePanel] = useState(false);
  const [view, setView] = useState<'chats' | 'contacts' | 'settings'>('chats');
  const [showSearch, setShowSearch] = useState(false);
  const [profileEdit, setProfileEdit] = useState(false);
  const [editName, setEditName] = useState('');
  const [editBio, setEditBio] = useState('');

  const tell = (message: string) => { setNotice(message); window.setTimeout(() => setNotice(''), 3200); };

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session?.user || !supabase) {
      setUser(null); setProfile(null); setConversations([]); setActive(null); setMessages([]);
      return;
    }
    setUser(session.user);
    void loadUser(session.user.id);
  }, [session]);

  const loadUser = async (uid: string) => {
    if (!supabase) return;
    const { data: p, error: pe } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (pe) { setError(pe.message); return; }
    if (p) {
      setProfile(p as Profile); setEditName(p.display_name || ''); setEditBio(p.bio || '');
    }
    await Promise.all([loadConversations(uid), loadFriends(uid)]);
  };

  const loadConversations = async (uid: string) => {
    if (!supabase) return;
    const { data: memberships, error: me } = await supabase.from('conversation_members')
      .select('conversation_id, conversations(id,title,is_group,updated_at)')
      .eq('user_id', uid);
    if (me) { setError(me.message); return; }
    const list = (memberships || []).map((x: any) => x.conversations).filter(Boolean) as Conversation[];
    list.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());
    setConversations(list);
    if (list.length && !active) setActive(list[0]);
    const ids = [...new Set(list.flatMap(c => [] as string[]))];
    void ids;
  };

  const loadFriends = async (uid: string) => {
    if (!supabase) return;
    const { data, error: fe } = await supabase.from('friendships').select('*')
      .or(`requester_id.eq.${uid},addressee_id.eq.${uid}`).eq('status', 'accepted');
    if (fe) return;
    const ids = (data || []).map((f: Friend) => f.requester_id === uid ? f.addressee_id : f.requester_id);
    if (!ids.length) { setFriends([]); return; }
    const { data: ps } = await supabase.from('profiles').select('*').in('id', ids);
    setFriends((ps || []) as Profile[]);
  };

  useEffect(() => {
    if (!active || !supabase || !user) { setMessages([]); return; }
    let alive = true;
    const fetchMessages = async () => {
      setBusy(true);
      const { data, error: me } = await supabase!.from('messages').select('*')
        .eq('conversation_id', active.id).order('created_at', { ascending: true }).limit(300);
      if (!alive) return;
      if (me) setError(me.message); else setMessages((data || []) as Message[]);
      setBusy(false);
    };
    void fetchMessages();
    const channel = supabase.channel(`messages-${active.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${active.id}` }, payload => {
        const incoming = payload.new as Message;
        setMessages(prev => prev.some(m => m.id === incoming.id) ? prev : [...prev, incoming]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${active.id}` }, payload => {
        const incoming = payload.new as Message;
        setMessages(prev => prev.map(m => m.id === incoming.id ? incoming : m));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${active.id}` }, payload => {
        const old = payload.old as Message;
        setMessages(prev => prev.filter(m => m.id !== old.id));
      }).subscribe();
    return () => { alive = false; void supabase!.removeChannel(channel); };
  }, [active?.id, user?.id]);

  useEffect(() => {
    if (!supabase || !user) return;
    const channel = supabase.channel(`memberships-${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversation_members', filter: `user_id=eq.${user.id}` }, () => void loadConversations(user.id))
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [user?.id]);

  const searchUsers = async (term: string) => {
    setQuery(term);
    if (!supabase || !user || term.trim().length < 2) { setPeople([]); return; }
    const { data, error: se } = await supabase.from('profiles').select('*')
      .or(`username.ilike.%${term.trim()}%,display_name.ilike.%${term.trim()}%`)
      .neq('id', user.id).limit(15);
    if (se) setError(se.message); else setPeople((data || []) as Profile[]);
  };

  const sendFriendRequest = async (target: Profile) => {
    if (!supabase || !user) return;
    const { error: fe } = await supabase.from('friendships').insert({ requester_id: user.id, addressee_id: target.id, status: 'pending' });
    if (fe) setError(fe.message); else tell(`Friend request sent to ${target.display_name}.`);
  };

  const startChat = async (target: Profile) => {
    if (!supabase || !user) return;
    setError('');
    const { data: existing } = await supabase.rpc('find_direct_conversation', { other_user: target.id });
    if (existing) {
      const found = conversations.find(c => c.id === existing);
      if (found) setActive(found); else { await loadConversations(user.id); const { data: row } = await supabase.from('conversations').select('*').eq('id', existing).single(); if (row) setActive(row as Conversation); }
      setView('chats'); setMobilePanel(false); return;
    }
    const { data: conv, error: ce } = await supabase.from('conversations').insert({ is_group: false, created_by: user.id }).select().single();
    if (ce || !conv) { setError(ce?.message || 'Could not create conversation.'); return; }
    const { error: cme } = await supabase.from('conversation_members').insert([{ conversation_id: conv.id, user_id: user.id, role: 'member' }, { conversation_id: conv.id, user_id: target.id, role: 'member' }]);
    if (cme) { setError(cme.message); return; }
    const c = conv as Conversation;
    setConversations(prev => [c, ...prev]); setActive(c); setView('chats'); setMobilePanel(false);
  };

  const createGroup = async () => {
    if (!supabase || !user) return;
    const title = window.prompt('Group name');
    if (!title?.trim()) return;
    const names = window.prompt('Invite usernames separated by commas (optional)') || '';
    const { data: conv, error: ce } = await supabase.from('conversations').insert({ title: title.trim(), is_group: true, created_by: user.id }).select().single();
    if (ce || !conv) { setError(ce?.message || 'Could not create group.'); return; }
    const members: { conversation_id: string; user_id: string; role: string }[] = [{ conversation_id: conv.id, user_id: user.id, role: 'admin' }];
    const wanted = names.split(',').map(s => s.trim().replace(/^@/, '')).filter(Boolean);
    if (wanted.length) {
      const { data: found, error: ue } = await supabase.from('profiles').select('id,username').in('username', wanted);
      if (ue) { setError(ue.message); return; }
      (found || []).forEach(p => { if (p.id !== user.id) members.push({ conversation_id: conv.id, user_id: p.id, role: 'member' }); });
    }
    const { error: cme } = await supabase.from('conversation_members').insert(members);
    if (cme) { setError(cme.message); return; }
    setConversations(prev => [conv as Conversation, ...prev]); setActive(conv as Conversation); setView('chats'); tell('Group created.');
  };

  const sendMessage = async (e?: FormEvent) => {
    e?.preventDefault();
    const content = draft.trim();
    if (!content || !active || !user || !supabase || busy) return;
    setDraft('');
    const { error: me } = await supabase.from('messages').insert({ conversation_id: active.id, sender_id: user.id, content });
    if (me) { setDraft(content); setError(me.message); }
    else await supabase.from('conversations').update({ updated_at: new Date().toISOString() }).eq('id', active.id);
  };

  const editMessage = async (m: Message) => {
    if (!supabase || m.sender_id !== user?.id) return;
    const next = window.prompt('Edit message', m.content);
    if (next === null || !next.trim()) return;
    const { error: me } = await supabase.from('messages').update({ content: next.trim(), edited_at: new Date().toISOString() }).eq('id', m.id);
    if (me) setError(me.message);
  };
  const deleteMessage = async (m: Message) => {
    if (!supabase || m.sender_id !== user?.id || !window.confirm('Delete this message?')) return;
    const { error: me } = await supabase.from('messages').delete().eq('id', m.id);
    if (me) setError(me.message);
  };
  const uploadFile = async (file?: File) => {
    if (!file || !supabase || !user || !active) return;
    if (file.size > 20 * 1024 * 1024) { setError('Files must be smaller than 20 MB.'); return; }
    const path = `${user.id}/${active.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const { error: ue } = await supabase.storage.from('chat-attachments').upload(path, file, { upsert: false });
    if (ue) { setError(ue.message); return; }
    const { data: urlData } = await supabase.storage.from('chat-attachments').createSignedUrl(path, 60 * 60 * 24 * 7);
    const body = `${file.type.startsWith('image/') ? '🖼️' : '📎'} ${file.name}${urlData?.signedUrl ? `\\n${urlData.signedUrl}` : ''}`;
    const { error: me } = await supabase.from('messages').insert({ conversation_id: active.id, sender_id: user.id, content: body });
    if (me) setError(me.message); else tell('File shared. Signed link expires in 7 days.');
  };

  const logout = async () => { await supabase?.auth.signOut(); setSession(null); };
  const saveProfile = async () => {
    if (!supabase || !user || !editName.trim()) return;
    const { error: pe } = await supabase.from('profiles').update({ display_name: editName.trim(), bio: editBio.trim() }).eq('id', user.id);
    if (pe) setError(pe.message); else { setProfile(p => p ? { ...p, display_name: editName.trim(), bio: editBio.trim() } : p); setProfileEdit(false); tell('Profile updated.'); }
  };
  const unreadCount = 0;
  const filteredConversations = useMemo(() => conversations.filter(c => (c.title || 'Direct conversation').toLowerCase().includes(query.toLowerCase())), [conversations, query]);
  const activeTitle = active?.is_group ? active.title || 'Untitled group' : active ? 'Private conversation' : 'Select a conversation';

  if (!isConfigured || !supabase) return <SetupScreen />;
  if (!session || !user) return <div className={`auth-page ${dark ? 'theme-dark' : 'theme-light'}`}>
    <div className="auth-orb orb-a" /><div className="auth-orb orb-b" />
    <div className="auth-brand"><div className="brand-mark"><MessageCircle size={27} /></div><span>chat<span className="brand-accent">wave</span></span><span className="beta">REAL-TIME</span></div>
    <div className="auth-card glass">
      <div className="auth-kicker"><Sparkles size={14} /> YOUR PEOPLE, IN REAL TIME</div>
      <h1>{authMode === 'login' ? 'Welcome back.' : 'Meet your new favorite inbox.'}</h1>
      <p className="muted">{authMode === 'login' ? 'Sign in to pick up where your conversations left off.' : 'Create your account and start connecting instantly.'}</p>
      {error && <div className="alert error">{error}</div>}
      <form onSubmit={async e => {
        e.preventDefault(); setAuthBusy(true); setError('');
        if (authMode === 'signup') {
          if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) { setError('Username must be 3–24 letters, numbers, or underscores.'); setAuthBusy(false); return; }
          const { error: ae } = await supabase!.auth.signUp({ email, password, options: { data: { username: username.toLowerCase(), display_name: displayName.trim() || username } } });
          if (ae) setError(ae.message); else tell('Account created. If email confirmation is enabled, check your inbox to verify your account.');
        } else {
          const { error: ae } = await supabase!.auth.signInWithPassword({ email, password });
          if (ae) setError(ae.message);
        }
        setAuthBusy(false);
      }}>
        {authMode === 'signup' && <>
          <label>Display name</label><input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="How people see you" maxLength={60} />
          <label>Unique username</label><input value={username} onChange={e => setUsername(e.target.value)} placeholder="e.g. alex_01" autoComplete="username" required />
        </>}
        <label>Email address</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required />
        <label>Password</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" minLength={8} autoComplete={authMode === 'login' ? 'current-password' : 'new-password'} required />
        {authMode === 'login' && <button type="button" className="text-button forgot" onClick={async () => { if (!email) { setError('Enter your email first.'); return; } const { error: re } = await supabase!.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin }); setError(re ? re.message : 'Password reset email requested. Check your inbox.'); }}>Forgot password?</button>}
        <button className="primary-btn full" disabled={authBusy}>{authBusy ? <span className="spinner" /> : authMode === 'login' ? 'Sign in' : 'Create account'} <ArrowUpRight size={17} /></button>
      </form>
      <div className="auth-switch">{authMode === 'login' ? 'New to ChatWave?' : 'Already have an account?'} <button className="text-button" onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setError(''); }}>{authMode === 'login' ? 'Create an account' : 'Sign in'}</button></div>
      <div className="secure-note"><ShieldCheck size={14} /> Protected by Supabase authentication</div>
    </div>
    <div className="auth-footer">Thoughtfully connected. <span>·</span> Built for your conversations.</div>
  </div>;

  return <div className={`app-shell ${dark ? 'theme-dark' : 'theme-light'} ${rtl ? 'rtl' : ''}`}>
    <aside className={`sidebar ${mobilePanel ? 'sidebar-open' : ''}`}>
      <div className="side-brand"><div className="brand-mark"><MessageCircle size={23} /></div><div><strong>chat<span className="brand-accent">wave</span></strong><small>YOUR SPACE TO CONNECT</small></div><button className="icon-btn mobile-close" onClick={() => setMobilePanel(false)}><X size={18}/></button></div>
      <div className="workspace-pill"><span className="workspace-dot" /> Personal workspace <ChevronDown size={14}/></div>
      <div className="side-nav">
        <button className={view === 'chats' ? 'nav-item active' : 'nav-item'} onClick={() => setView('chats')}><MessageCircle size={18}/> Messages <span className="nav-count">{unreadCount || ''}</span></button>
        <button className={view === 'contacts' ? 'nav-item active' : 'nav-item'} onClick={() => setView('contacts')}><Users size={18}/> Contacts</button>
        <button className="nav-item" onClick={createGroup}><Plus size={18}/> New group</button>
      </div>
      <div className="list-heading"><span>{view === 'contacts' ? 'YOUR CONTACTS' : 'RECENT CHATS'}</span><button className="icon-btn tiny" onClick={() => setShowSearch(!showSearch)} title="Search"><Search size={15}/></button></div>
      {showSearch && <div className="search-wrap"><Search size={15}/><input placeholder="Search chats..." value={query} onChange={e => setQuery(e.target.value)}/><button onClick={() => setQuery('')}><X size={13}/></button></div>}
      <div className="conversation-list">
        {view === 'contacts' ? friends.map((f, i) => <button key={f.id} className="conversation-item" onClick={() => startChat(f)}><Avatar name={f.display_name} color={colors[i % colors.length]} online={false}/><span className="conversation-copy"><strong>{f.display_name}</strong><small>@{f.username}</small></span><MessageCircle size={16} className="item-action"/></button>)
          : filteredConversations.map((c, i) => <button key={c.id} className={`conversation-item ${active?.id === c.id ? 'selected' : ''}`} onClick={() => { setActive(c); setMobilePanel(false); }}><Avatar name={c.is_group ? c.title || 'Group' : 'Chat'} color={colors[i % colors.length]} group={c.is_group}/><span className="conversation-copy"><strong>{c.title || 'Direct chat'}</strong><small>{c.is_group ? 'Group conversation' : 'Private chat'}</small></span><span className="conversation-meta"><small>{new Date(c.updated_at).toLocaleDateString([], { month: 'short', day: 'numeric' })}</small></span></button>)}
        {view !== 'contacts' && filteredConversations.length === 0 && <div className="empty-mini"><div className="empty-icon"><MessageCircle size={20}/></div><strong>Your inbox starts here</strong><span>Search for someone to begin a conversation.</span></div>}
      </div>
      <div className="sidebar-bottom">
        <div className="plan-card"><div className="plan-icon"><Sparkles size={16}/></div><div><strong>Your space, your rules</strong><small>Keep conversations kind and safe.</small></div></div>
        <button className={view === 'settings' ? 'nav-item active' : 'nav-item'} onClick={() => { setView('settings'); setMobilePanel(false); }}><Settings size={18}/> Settings</button>
        <div className="account-row"><Avatar name={profile?.display_name || user.email || 'You'} color="#8978ff"/><div className="account-copy"><strong>{profile?.display_name || user.email?.split('@')[0]}</strong><small>@{profile?.username || 'member'}</small></div><button className="icon-btn" onClick={logout} title="Log out"><LogOut size={17}/></button></div>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setMobilePanel(true)}><Menu size={19}/></button><div className="breadcrumbs"><span>Workspace</span><span className="crumb-slash">/</span><strong>{view === 'settings' ? 'Settings' : view === 'contacts' ? 'Contacts' : 'Messages'}</strong></div><div className="top-actions"><span className="connection-status"><i/> Connected</span><button className="icon-btn" title="Toggle theme" onClick={() => setDark(!dark)}>{dark ? <Sun size={18}/> : <Moon size={18}/>}</button><button className="icon-btn" title="Notifications" onClick={() => tell('You’re all caught up.') }><Bell size={18}/></button><button className="icon-btn" title="Help" onClick={() => tell('Tip: search a username to find people and start chatting.')}><CircleHelp size={18}/></button></div></header>
      {error && <div className="global-alert"><span>{error}</span><button onClick={() => setError('')}><X size={15}/></button></div>}
      {view === 'settings' ? <section className="settings-page"><div className="page-eyebrow">PREFERENCES</div><h1>Make it yours<span>.</span></h1><p className="muted">A little space to set up ChatWave your way.</p>
        <div className="settings-grid"><div className="settings-card"><div className="settings-icon"><Users size={19}/></div><h3>Your profile</h3><p>Help friends recognize you.</p>{profileEdit ? <><label>Display name</label><input value={editName} onChange={e => setEditName(e.target.value)}/><label>Bio</label><textarea value={editBio} onChange={e => setEditBio(e.target.value)} maxLength={160}/><button className="primary-btn" onClick={saveProfile}>Save profile</button></> : <><strong>{profile?.display_name || 'Your name'}</strong><p>{profile?.bio || 'Add a short bio to introduce yourself.'}</p><button className="secondary-btn" onClick={() => setProfileEdit(true)}>Edit profile</button></>}</div>
        <div className="settings-card"><div className="settings-icon"><Sun size={19}/></div><h3>Appearance</h3><p>Choose the atmosphere that feels right.</p><button className="setting-choice" onClick={() => setDark(true)}><Moon size={17}/> Dark mode <span>{dark ? '✓' : ''}</span></button><button className="setting-choice" onClick={() => setDark(false)}><Sun size={17}/> Light mode <span>{!dark ? '✓' : ''}</span></button></div>
        <div className="settings-card"><div className="settings-icon"><Languages size={19}/></div><h3>Language & layout</h3><p>English or Pashto interface direction.</p><button className="setting-choice" onClick={() => { setRtl(false); tell('English layout selected.'); }}>English (LTR) <span>{!rtl ? '✓' : ''}</span></button><button className="setting-choice" onClick={() => { setRtl(true); tell('Pashto layout selected. Add translated strings to localize every label.'); }}>پښتو (RTL) <span>{rtl ? '✓' : ''}</span></button></div>
        <div className="settings-card"><div className="settings-icon"><LockKeyhole size={19}/></div><h3>Account security</h3><p>Manage your sign-in session.</p><button className="secondary-btn" onClick={async () => { if (!user?.email) return; const { error: re } = await supabase!.auth.resetPasswordForEmail(user.email, { redirectTo: window.location.origin }); tell(re ? re.message : 'Password reset email requested.'); }}>Request password reset</button><button className="danger-btn" onClick={logout}><LogOut size={15}/> Log out</button></div></div>
      </section> : view === 'contacts' ? <section className="discover-page"><div className="page-eyebrow">PEOPLE</div><h1>Find your people<span>.</span></h1><p className="muted">Search by username or display name to connect.</p><div className="discover-search"><Search size={19}/><input value={query} onChange={e => void searchUsers(e.target.value)} placeholder="Search usernames, names..." autoFocus/></div><div className="people-list">{people.map((p, i) => <div className="person-card" key={p.id}><Avatar name={p.display_name} color={colors[i % colors.length]}/><div className="person-info"><strong>{p.display_name}</strong><small>@{p.username}</small><p>{p.bio || 'Ready to connect on ChatWave.'}</p></div><button className="secondary-btn" onClick={() => void sendFriendRequest(p)}><UserPlus size={15}/> Add friend</button><button className="primary-btn" onClick={() => void startChat(p)}><MessageCircle size={15}/> Message</button></div>)}{query.length >= 2 && people.length === 0 && <div className="empty-state"><Search size={25}/><strong>No people found</strong><span>Try a different username or name.</span></div>}{query.length < 2 && <div className="empty-state"><Users size={25}/><strong>Who’s on your mind?</strong><span>Type at least 2 characters to search for people.</span></div>}</div></section> : <div className="chat-layout">
        <section className="chat-panel">
          {active ? <>
            <div className="chat-header"><Avatar name={activeTitle} color={colors[0]} group={active.is_group}/><div className="chat-header-copy"><strong>{activeTitle}</strong><small><i className="green-dot"/> {active.is_group ? 'Group conversation' : 'Private conversation'}</small></div><div className="chat-tools"><button className="icon-btn" title="Search messages" onClick={() => { const term = window.prompt('Search messages in this chat'); if (term) { const m = messages.find(x => x.content.toLowerCase().includes(term.toLowerCase())); tell(m ? `Found: “${m.content.slice(0, 80)}”` : 'No matching message in loaded history.'); } }}><Search size={18}/></button><button className="icon-btn" title="Voice call (not configured)" onClick={() => tell('Calling is not configured yet. Add a WebRTC signaling service to enable calls.')}><Phone size={18}/></button><button className="icon-btn" title="Video call (not configured)" onClick={() => tell('Video calling is not configured yet. Add WebRTC signaling and TURN servers.')}><Video size={18}/></button><button className="icon-btn" title="More" onClick={() => tell('Conversation options: use the group creator and database policies to manage membership.')}><MoreHorizontal size={19}/></button></div></div>
            <div className="message-area"><div className="date-divider"><span>MESSAGES</span></div>{busy && <div className="loading-line"><span className="spinner small"/> Loading messages…</div>}
              {messages.length === 0 && !busy && <div className="chat-empty"><div className="empty-orbit"><MessageCircle size={29}/></div><h2>Make the first move.</h2><p>Say hello and get the conversation going.</p><div className="suggestions"><button onClick={() => setDraft('Hey! How’s it going? 👋')}>👋 Say hello</button><button onClick={() => setDraft('Got a minute to chat?')}>💬 Quick question</button><button onClick={() => setDraft('Hope you’re having a great day ✨')}>✨ Send good vibes</button></div></div>}
              {messages.map((m, i) => { const mine = m.sender_id === user.id; const prev = messages[i - 1]; const showDate = !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString(); return <div key={m.id}>{showDate && <div className="date-divider"><span>{new Date(m.created_at).toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' })}</span></div>}<div className={`message-row ${mine ? 'mine' : ''}`}><div className="message-avatar">{mine ? initials(profile?.display_name) : '·'}</div><div className="message-content"><div className="message-meta"><strong>{mine ? 'You' : 'Member'}</strong><span>{timeLabel(m.created_at)}{m.edited_at ? ' · edited' : ''}</span></div><div className="bubble-wrap"><div className="bubble">{m.content.split('\\n').map((line, ix) => <span key={ix}>{line}{ix < m.content.split('\\n').length - 1 && <br/>}</span>)}</div>{mine && <div className="message-actions"><button title="Edit message" onClick={() => void editMessage(m)}>Edit</button><button title="Delete message" onClick={() => void deleteMessage(m)}>Delete</button></div>}</div></div></div></div>; })}
            </div>
            <form className="composer" onSubmit={sendMessage}><div className="composer-tools"><label className="icon-btn" title="Attach a file"><Paperclip size={18}/><input type="file" hidden accept="image/*,video/*,.pdf,.doc,.docx,.txt" onChange={e => { void uploadFile(e.target.files?.[0]); e.currentTarget.value = ''; }}/></label><button type="button" className="icon-btn" title="Add emoji" onClick={() => setDraft(d => d + ' 😊')}><Smile size={18}/></button></div><textarea value={draft} onChange={e => setDraft(e.target.value)} placeholder="Write a message…" rows={1} maxLength={5000} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendMessage(); } }}/><span className="composer-hint">Enter to send · Shift + Enter for a new line</span><button className="send-btn" type="submit" disabled={!draft.trim()} title="Send message"><Send size={18}/></button></form>
          </> : <div className="no-chat"><div className="empty-orbit"><MessageCircle size={30}/></div><h2>Every great conversation starts somewhere.</h2><p>Choose a chat or find a person to say hello.</p><button className="primary-btn" onClick={() => { setView('contacts'); setMobilePanel(false); }}><Search size={16}/> Find people</button></div>}
        </section>
        <aside className="right-panel"><div className="right-top"><span>YOUR SPACE</span><button className="icon-btn tiny" onClick={() => tell('Your workspace is private to your account.')}><MoreHorizontal size={16}/></button></div><div className="profile-hero"><div className="profile-glow"/><Avatar name={profile?.display_name || 'You'} color="#8978ff" big/><div className="online-badge"/><h3>{profile?.display_name || 'Welcome'}</h3><span className="handle">@{profile?.username || 'member'}</span><p>{profile?.bio || 'A little about you goes a long way.'}</p><button className="secondary-btn" onClick={() => { setView('settings'); setProfileEdit(true); }}>Edit profile</button></div><div className="right-divider"/><div className="quick-section"><div className="section-label">QUICK ACCESS <span>{conversations.length}</span></div><button className="quick-link" onClick={() => { setView('contacts'); setQuery(''); }}><span className="quick-icon purple"><Users size={17}/></span><span><strong>Contacts</strong><small>Your connections</small></span><ArrowUpRight size={15}/></button><button className="quick-link" onClick={createGroup}><span className="quick-icon teal"><Plus size={17}/></span><span><strong>Start a group</strong><small>Bring everyone together</small></span><ArrowUpRight size={15}/></button><button className="quick-link" onClick={() => tell('Notifications are shown here as they arrive; enable browser permission to add push notifications in a future release.')}><span className="quick-icon orange"><Bell size={17}/></span><span><strong>Notifications</strong><small>Stay in the loop</small></span><ArrowUpRight size={15}/></button></div><div className="privacy-card"><ShieldCheck size={18}/><div><strong>Your conversations matter.</strong><p>Access is controlled by database policies. Never share your account credentials.</p></div></div><div className="right-foot"><span><i/> All systems operational</span><span>CHATWAVE v1.0</span></div></aside>
      </div>}
    </main>
    {notice && <div className="toast"><Check size={16}/>{notice}</div>}
  </div>;
}

function Avatar({ name, color, online, group, big }: { name: string; color: string; online?: boolean; group?: boolean; big?: boolean }) {
  return <div className={`avatar ${big ? 'avatar-big' : ''}`} style={{ '--avatar-color': color } as React.CSSProperties}>{group ? <Users size={big ? 25 : 18}/> : initials(name)}{online && <i/>}</div>;
}

function SetupScreen() {
  const [showHelp, setShowHelp] = useState(false);
  return <div className="setup-page"><div className="setup-card glass"><div className="brand-mark"><MessageCircle size={26}/></div><div className="page-eyebrow">ONE-TIME SETUP</div><h1>Let’s connect<br/><span>your backend.</span></h1><p className="muted">ChatWave needs a Supabase project for secure accounts, PostgreSQL storage, and live message updates. Your credentials are not configured yet.</p><ol><li><b>1</b><span>Create a project at <a href="https://supabase.com" target="_blank" rel="noreferrer">supabase.com</a>.</span></li><li><b>2</b><span>Run <code>supabase/schema.sql</code> in the Supabase SQL Editor.</span></li><li><b>3</b><span>Copy <code>.env.example</code> to <code>.env</code> and add your project URL and anon key.</span></li><li><b>4</b><span>Enable Realtime for the <code>messages</code> table and create the private storage bucket described in README.</span></li></ol><button className="primary-btn full" onClick={() => setShowHelp(!showHelp)}>{showHelp ? 'Hide configuration details' : 'Show configuration details'} <ArrowUpRight size={16}/></button>{showHelp && <div className="help-panel">Run <code>npm install</code>, then <code>npm run dev</code>. Restart the dev server after editing <code>.env</code>. Do not put a Supabase service-role key in frontend environment variables.</div>}<p className="setup-foot"><LockKeyhole size={14}/> Frontend uses only the publishable/anon key; Row Level Security protects data.</p></div></div>;
}
