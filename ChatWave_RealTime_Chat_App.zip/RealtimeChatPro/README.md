# ChatWave — Professional Real-Time Chat

A React + TypeScript + Vite chat application with a premium responsive interface and Supabase backend integration.

## Included

- Email/password sign-up, login, logout, and password-reset email flow
- Unique usernames and editable display name/bio
- User search, friend requests, accepted contacts
- Private one-to-one conversations and group creation by username
- Persistent messages, live INSERT/UPDATE/DELETE updates using Supabase Realtime
- Edit/delete your own messages
- File uploads to a private Supabase Storage bucket (20 MB limit; signed links expire after 7 days)
- Dark/light mode, English/Pashto direction toggle, responsive mobile sidebar
- PostgreSQL schema and Row Level Security policies

## Requirements

- Node.js 20 or later (recommended)
- A Supabase project
- npm

## 1. Create Supabase backend

1. Create a project at https://supabase.com.
2. Open **SQL Editor** in your Supabase dashboard.
3. Run all of `supabase/schema.sql`.
4. In **Project Settings → API**, copy the Project URL and publishable/anon key.
5. In **Database → Replication** (or the Realtime settings in your project dashboard), enable Realtime for `public.messages`.
6. In **Authentication → URL Configuration**, set your local Site URL to `http://localhost:5173` and add your production domain to Redirect URLs.
7. Configure email confirmation and SMTP according to your launch requirements. For reliable production email delivery, configure a custom SMTP provider.

The SQL creates a private `chat-attachments` bucket. Files are uploaded under a user's own folder. The starter currently shares a signed URL in message text; signed URLs expire after seven days. For sensitive deployments, store attachment metadata in `attachments` and issue short-lived URLs only after verifying conversation membership server-side.

## 2. Install and configure

```bash
npm install
cp .env.example .env
```

On Windows PowerShell, copy the file with:

```powershell
Copy-Item .env.example .env
```

Edit `.env`:

```dotenv
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Only use the publishable/anon key in frontend code. **Never put a Supabase service-role key in `.env` variables prefixed with `VITE_` or expose it in the browser.**

## 3. Run locally

```bash
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

Build a production bundle:

```bash
npm run build
npm run preview
```

## 4. Deploy

Deploy the repository to Vercel, Netlify, Cloudflare Pages, or another static hosting service:
- Build command: `npm run build`
- Output directory: `dist`
- Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the host's environment settings.
- Add your deployed domain to Supabase Authentication URL Configuration.
- Re-run `npm run build` after environment variable changes.

## Important limitations before public launch

This is a functional starter, not a fully audited enterprise messenger. Before real users depend on it:

- Implement server-side rate limiting for auth, friend requests, and messages (for example with Edge Functions and a database rate-limit table).
- Add an admin role system backed by server-controlled claims and moderation workflows. Do not let users set their own admin role.
- Add robust message delivery/read receipts, typing indicators, presence/last-seen, unread counts, push notifications, message reactions, forwarding, archiving/muting, and full attachment records.
- The included `friendships` table supports request creation and accept/decline at the database level; this UI does not yet provide the incoming request inbox or accept/decline screens.
- Group creation is included, but advanced group management/member permissions and announcement/pinned-message UI remain to be built.
- Voice/video calling, GIF search, stickers, and end-to-end encryption are not implemented. The call buttons explain that calling needs WebRTC signaling and TURN infrastructure.
- Pashto toggle currently enables RTL layout; complete localization requires translating every interface string.
- The app does not claim end-to-end encryption. Supabase transport security and database RLS are not the same as E2EE.
- Signed file URLs are bearer links and can be forwarded until expiry. Use a server-side download endpoint that verifies membership if your files require stronger privacy.
- Review every RLS policy and test it with multiple users before public deployment. Configure backups, monitoring, abuse reporting, and a privacy policy.

## Database tables

- `profiles`
- `conversations`
- `conversation_members`
- `messages`
- `attachments`
- `friendships`
- `notifications`

The SQL schema uses PostgreSQL foreign keys, constraints, indexes, RLS, and security-definer helper functions with a restricted search path.

## Troubleshooting

- **"Invalid API key"**: verify `.env` values and restart Vite.
- **Sign-up succeeds but login is not immediate**: email confirmation may be enabled; verify your email.
- **Messages don't update live**: ensure Realtime replication is enabled for `public.messages`.
- **Profile username conflict**: usernames are unique; choose a different one.
- **File upload denied**: check that the private bucket and storage policies were created and the file type is allowed.
