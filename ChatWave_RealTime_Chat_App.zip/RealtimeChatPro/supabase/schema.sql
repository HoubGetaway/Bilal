-- ChatWave database schema for Supabase PostgreSQL.
-- Run as a project owner in Supabase SQL Editor. Never expose service_role keys in the browser.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-zA-Z0-9_]{3,24}$'),
  display_name text not null default 'New member' check (char_length(display_name) between 1 and 60),
  avatar_url text,
  bio text not null default '' check (char_length(bio) <= 160),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text check (title is null or char_length(title) between 1 and 80),
  is_group boolean not null default false,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 5000),
  created_at timestamptz not null default now(),
  edited_at timestamptz
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at desc);

create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.messages(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  content_type text not null,
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 20971520),
  created_at timestamptz not null default now()
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references auth.users(id) on delete cascade,
  addressee_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','blocked','declined')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (requester_id <> addressee_id),
  unique (requester_id, addressee_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  kind text not null check (kind in ('message','friend_request','friend_accepted','group_invite','system')),
  payload jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);

-- Create a profile for each new auth user. Username comes from sign-up metadata;
-- users should choose a valid unique username in the app.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  chosen_username text;
  chosen_name text;
begin
  chosen_username := lower(coalesce(new.raw_user_meta_data ->> 'username', 'user_' || substr(new.id::text, 1, 8)));
  if chosen_username !~ '^[a-z0-9_]{3,24}$' then
    chosen_username := 'user_' || substr(new.id::text, 1, 8);
  end if;
  chosen_name := coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), chosen_username);
  insert into public.profiles(id, username, display_name)
  values(new.id, chosen_username, left(chosen_name, 60))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_conversation_member(cid uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = cid and cm.user_id = (select auth.uid())
  );
$$;

create or replace function public.find_direct_conversation(other_user uuid)
returns uuid language plpgsql stable security definer set search_path = '' as $$
declare found_id uuid;
begin
  if auth.uid() is null or other_user = auth.uid() then return null; end if;
  select c.id into found_id
  from public.conversations c
  join public.conversation_members me on me.conversation_id = c.id and me.user_id = auth.uid()
  join public.conversation_members them on them.conversation_id = c.id and them.user_id = other_user
  where c.is_group = false
    and (select count(*) from public.conversation_members x where x.conversation_id = c.id) = 2
  limit 1;
  return found_id;
end; $$;
grant execute on function public.find_direct_conversation(uuid) to authenticated;
grant execute on function public.is_conversation_member(uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.attachments enable row level security;
alter table public.friendships enable row level security;
alter table public.notifications enable row level security;

-- Profiles are discoverable for username search. Only the profile owner can edit their profile.
create policy "Authenticated users can view profiles" on public.profiles for select to authenticated using (true);
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (id = (select auth.uid()));
create policy "Users update own profile" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

create policy "Members can view conversations" on public.conversations for select to authenticated
using (public.is_conversation_member(id));
create policy "Authenticated users can create conversations" on public.conversations for insert to authenticated
with check (created_by = (select auth.uid()));
create policy "Members can update conversations" on public.conversations for update to authenticated
using (public.is_conversation_member(id)) with check (public.is_conversation_member(id));

create policy "Members can view member list" on public.conversation_members for select to authenticated
using (public.is_conversation_member(conversation_id));
create policy "Conversation creator can add initial members" on public.conversation_members for insert to authenticated
with check (
  user_id = (select auth.uid())
  or exists (select 1 from public.conversations c where c.id = conversation_id and c.created_by = (select auth.uid()))
  or exists (select 1 from public.conversation_members cm where cm.conversation_id = conversation_id and cm.user_id = (select auth.uid()) and cm.role = 'admin')
);
create policy "Admins or self can remove members" on public.conversation_members for delete to authenticated
using (user_id = (select auth.uid()) or exists (
  select 1 from public.conversation_members cm where cm.conversation_id = conversation_id and cm.user_id = (select auth.uid()) and cm.role = 'admin'
));
create policy "Admins can update member roles" on public.conversation_members for update to authenticated
using (exists (select 1 from public.conversation_members cm where cm.conversation_id = conversation_id and cm.user_id = (select auth.uid()) and cm.role = 'admin'))
with check (exists (select 1 from public.conversation_members cm where cm.conversation_id = conversation_id and cm.user_id = (select auth.uid()) and cm.role = 'admin'));

create policy "Members can read messages" on public.messages for select to authenticated
using (public.is_conversation_member(conversation_id));
create policy "Members can send as themselves" on public.messages for insert to authenticated
with check (sender_id = (select auth.uid()) and public.is_conversation_member(conversation_id));
create policy "Authors can edit own messages" on public.messages for update to authenticated
using (sender_id = (select auth.uid()) and public.is_conversation_member(conversation_id))
with check (sender_id = (select auth.uid()) and public.is_conversation_member(conversation_id));
create policy "Authors can delete own messages" on public.messages for delete to authenticated
using (sender_id = (select auth.uid()) and public.is_conversation_member(conversation_id));

create policy "Members can read attachments" on public.attachments for select to authenticated
using (exists (select 1 from public.messages m where m.id = message_id and public.is_conversation_member(m.conversation_id)));
create policy "Members can add attachments to own messages" on public.attachments for insert to authenticated
with check (exists (select 1 from public.messages m where m.id = message_id and m.sender_id = (select auth.uid()) and public.is_conversation_member(m.conversation_id)));

create policy "Participants can view their friendships" on public.friendships for select to authenticated
using (requester_id = (select auth.uid()) or addressee_id = (select auth.uid()));
create policy "Users can send friend requests" on public.friendships for insert to authenticated
with check (requester_id = (select auth.uid()) and status = 'pending');
create policy "Recipient can accept or decline; requester can cancel" on public.friendships for update to authenticated
using (addressee_id = (select auth.uid()) or requester_id = (select auth.uid()))
with check ((addressee_id = (select auth.uid()) and status in ('accepted','declined','blocked')) or (requester_id = (select auth.uid()) and status in ('pending','blocked')));

create policy "Users can view own notifications" on public.notifications for select to authenticated
using (user_id = (select auth.uid()));
create policy "Users can mark own notifications read" on public.notifications for update to authenticated
using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Private bucket. Storage policies restrict files to a user's own folder for uploads.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat-attachments', 'chat-attachments', false, 20971520,
  array['image/jpeg','image/png','image/webp','image/gif','video/mp4','application/pdf','text/plain','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'])
on conflict (id) do update set public = false, file_size_limit = 20971520;

create policy "Users upload into their own folder" on storage.objects for insert to authenticated
with check (bucket_id = 'chat-attachments' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "Owners can read their uploaded files" on storage.objects for select to authenticated
using (bucket_id = 'chat-attachments' and (storage.foldername(name))[1] = (select auth.uid())::text);

-- Realtime is enabled via Dashboard > Database > Replication > messages.
-- Production hardening recommended: server-side rate limiting, moderation queues, and
-- a dedicated function for admin-only role grants. Do not allow client-side role elevation.
